from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
# Create your views here.

from django.contrib.auth import authenticate,login,logout
from django.db.models.query_utils import Q

def home(request):
   return render(request,'home.html')

def add_user(request):
   if request.method=='POST':
      f=UserCreationForm(request.POST)
      f.save()
      return redirect('/')
   else:
      f=UserCreationForm()
      context={'form':f}
      return render(request,'form.html',context)
   
def login_view(request):
   if request.method=='POST':
      uname=request.POST.get('username')
      passw=request.POST.get('password')
      
      user=authenticate(request,username=uname,password=passw)
      
      if user is not None:
         request.session['uid']=user.id
         login(request,user)
         return redirect('/')
         
      else:
         return render(request,'login.html')
         
      
   else:
      return render(request,'login.html')
   
   
   
def logout_view(request):
   logout(request)
   return redirect('/')

from .models import Product,Cart
def product_list(request):
   pl=Product.objects.all()
   context={'pl':pl}
   return render(request,'plist.html',context)

from django.contrib.auth.models import User
def add_to_cart(request,pid):
   uid=request.session.get('uid')
   user=User.objects.get(id=uid)
   
   p=Product.objects.get(id=pid)
   cart = Cart.objects.filter(user=request.user, product=p).first()
   if cart:
   # c=Cart()
   # c.product=product
   # uid=request.session.get('uid')
   # user=User.objects.get(id=uid)
   # c.user=user
      cart.quantity += 1
      cart.save()
   else:
      Cart.objects.create(user=request.user, product=p, quantity=1)
   return redirect('/')

def cart_list(request):
   uid=request.session.get('uid')
   user=User.objects.get(id=uid)
   cl=Cart.objects.filter(user=user)
   total_price = sum(i.product.price * i.quantity for i in cl)
   context={'cl':cl, 'total_price': total_price}
   return render(request,'clist.html',context)

def remove_from_cart(req, pid):
   item = Cart.objects.get(id=pid)

   if item.quantity > 1:
      item.quantity -= 1
      item.save()
   else:
      item.delete()

   return redirect('/clist')
   
   # item = Cart.objects.get(id=pid)
   # # if item.quantity > 1:
   # #    item.quantity -= 1
   # #    return redirect('/clist')
   # # else:
   # # item.delete()
   # item.delete()
   # return redirect('/clist')
