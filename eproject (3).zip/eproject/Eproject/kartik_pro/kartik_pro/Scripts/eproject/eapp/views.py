from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login,logout
# from .models import ModelName
# from django import forms
# from .forms import FlowerForm

# Create your views here.

def home(request):
    return render(request,'home.html')

def add_user(request):
    if request.method=='POST':
        f=UserCreationForm(request.POST)
        f.save()
        return redirect('/')
    else: 
        f=UserCreationForm()
        context={'form':f}
        return render(request,'adduser.html',context)   
       

def login_view(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        passw=request.POST.get('password')
        user=authenticate(request,username=uname,password=passw)
        if user is not None:
            request.session['uid']=user.id
            login(request,user)
            return redirect('/')
        else:

            return render(request,'login.html')
        
    return render(request,'login.html')

def logout_view(request):
    logout(request)
    return redirect('/')


from .models import Product

def product_list(request):
    pl=Product.objects.all()
    context={'pl':pl}
    return render(request,'plist.html',context)

from .models import Cart

from django.contrib.auth.models import User
def add_to_cart(request,pid):
    product=Product.objects.get(id=pid)
    c=Cart()
    c.product=product
    uid=request.session.get('uid')
    user=User.objects.get(id=uid)
    c.user=user
    c.save()
    return redirect('/')


def cart_list(request):
    uid=request.session.get('uid')
    user=User.objects.get(id=uid)
    cl=Cart.objects.all()
    context={'cl':cl}
    return render(request,'clist.html',context)


def remove_from_cart(req, pid):
   item = Cart.objects.get(id=pid)

   if item.quantity > 1:
      item.quantity -= 1
      item.save()
   else:
      item.delete()

   return redirect('/clist')

# from django.shortcuts import render
# from .models import Product


# def search_feature(request):
#     # Check if the request is a post request.
#    srch=request.POST.get('srch')
#    eapp=Product.objects.filter(description__contain=srch)
#    context={'eapp':eapp}
#    return render(request,'clist.html',context)

def pro_pay(request,pid):
    product=Product.objects.get(id=pid)
    c=Pay()
    c.product=product
    uid=request.session.get('uid')
    user=User.objects.get(id=uid)
    c.user=user
    c.save()
    return redirect('/')