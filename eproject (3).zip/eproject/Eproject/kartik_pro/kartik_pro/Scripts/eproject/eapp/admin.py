from django.contrib import admin

# Register your models here.
from .models import Category,Product,Cart

class CategoryAdmin(admin.ModelAdmin):
    list_display=['name'],
    list_display=['description']

admin.site.register(Category,CategoryAdmin)

class ProductAdmin(admin.ModelAdmin):
    list_display=['name','price','description','category']
admin.site.register(Product, ProductAdmin)


class CartAdmin(admin.ModelAdmin):
   list_display=['user', 'product', 'quantity']
admin.site.register(Cart,CartAdmin)