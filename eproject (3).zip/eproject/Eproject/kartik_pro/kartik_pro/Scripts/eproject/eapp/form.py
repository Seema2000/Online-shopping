# from django import Forms
# from .models import Flower
# from .forms import FlowerForm

# class FlowerForm(forms.ModelForm):
#     class Meta:
#         model = Flower
#         fields = ['name', 'description', 'price','image']

# <form method="post" action="{% url 'your_view_name' %}" enctype="multipart/form-data">
#     {% csrf_token %}
#     # <!-- Your form fields, including the image field -->
#     <input type="file" name="image">
#     # <!-- Other form fields... -->
#     <button type="submit">Submit</button>
# </form>
